package usecase

import (
	"go-auth-poc/pkg/domain/model"
	"go-auth-poc/pkg/repository"
	"time"
)

type UserUseCase interface {
	GetUsers(u []*model.User) ([]*model.User, error)
	Create(u *model.User) (*model.User, error)
	GetUser(u *model.User) (*model.User, error)
	UpdateUser(u *model.User) (*model.User, error)
	DeleteUser(u *model.User) error
}

type userUsecase struct {
	userRepository repository.UserRepository
}

func NewUserUsecase(r repository.UserRepository) UserUseCase {
	return &userUsecase{r}
}

func (uu *userUsecase) GetUsers(u []*model.User) ([]*model.User, error) {
	user, err := uu.userRepository.GetUsers(u)
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (uu *userUsecase) Create(u *model.User) (*model.User, error) {
	user, err := uu.userRepository.CreateUser(u)

	if err != nil {
		return nil, err
	}

	return user, nil
}

func (uu *userUsecase) GetUser(u *model.User) (*model.User, error) {
	user, err := uu.userRepository.GetUser(u)
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (uu *userUsecase) UpdateUser(u *model.User) (*model.User, error) {
	user, err := uu.userRepository.GetUser(&model.User{ID: u.ID})
	if err != nil {
		return nil, err
	}

	user.Name = u.Name
	user.Email = u.Email
	user.Password = u.Password
	user.ImageURL = u.ImageURL
	user.UpdatedAt = time.Now()

	user, err = uu.userRepository.UpdateUser(user)
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (uu *userUsecase) DeleteUser(u *model.User) error {
	err := uu.userRepository.DeleteUser(u)
	if err != nil {
		return err
	}

	return nil
}
