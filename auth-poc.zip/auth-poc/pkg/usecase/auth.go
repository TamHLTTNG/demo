package usecase

import (
	"go-auth-poc/pkg/repository"

	"github.com/Nerzal/gocloak/v13"
)

type AuthUseCase interface {
	GetAccessToken(token string) (string, error)
	CreateLocalJWT(information map[string]interface{}) (string, error)
	GetKeyCloakUserInfo(token string) (*gocloak.UserInfo, error)
	ValidateToken(token string) (bool, error)
}

type authUseCase struct {
	authRepository repository.AuthRepository
}

func NewAuthUseCase(a repository.AuthRepository) AuthUseCase {
	return &authUseCase{a}
}

func (ac *authUseCase) GetAccessToken(authorizationCode string) (string, error) {
	result, err := ac.authRepository.GetAccessToken(authorizationCode)
	if err != nil {
		return "", err
	}
	return result.AccessToken, nil
}

func (ac *authUseCase) CreateLocalJWT(information map[string]interface{}) (string, error) {
	result, err := ac.authRepository.CreateLocalJWT(information)
	if err != nil {
		return "", err
	}
	return result, nil
}

func (ac *authUseCase) GetKeyCloakUserInfo(token string) (*gocloak.UserInfo, error) {
	result, err := ac.authRepository.GetUserInfo(token)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (ac *authUseCase) ValidateToken(token string) (bool, error) {
	result, err := ac.authRepository.GetUserInfo(token)
	if err != nil {
		return false, err
	}
	var emptyValue gocloak.UserInfo
	if result == &emptyValue {
		return false, err
	}
	return true, nil
}
