package util

type endpointURL struct {
	Token   string
	Inspect string
	Revoke  string
	User    string
	Session string
}

var OpenAM = endpointURL{
	Token:   "/openam/json/access_token",
	Inspect: "/openam/json/inspect",
	Revoke:  "/openam/json/revoke",
	User:    "/openam/json/users/",
	Session: "/openam/json/sessions/",
}

var KeyCloak = endpointURL{
	Token:   "/protocol/openid-connect/token",
	Inspect: "/protocol/openid-connect/token/introspect",
	Revoke:  "/protocol/openid-connect/revoke",
	User:    "/protocol/openid-connect/userinfo",
	Session: "",
}
