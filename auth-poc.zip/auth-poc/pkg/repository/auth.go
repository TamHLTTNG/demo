package repository

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"go-auth-poc/pkg/config"
	"go-auth-poc/pkg/util"
	"io"
	"net/http"
	"net/url"

	"github.com/Nerzal/gocloak/v13"
	"github.com/dgrijalva/jwt-go"
	"github.com/jinzhu/gorm"
)

type authRepository struct {
	db *gorm.DB
}

func NewAuthRepository(db *gorm.DB) AuthRepository {
	return &authRepository{db}
}

func (ar *authRepository) GetAccessToken(authorizationCode string) (*gocloak.JWT, error) {
	// hostname := config.C.Server.KeyCloakBaseURL
	// clientid := config.C.Server.KeyCloakClientID
	// clientSecret := config.C.Server.KeyCloakSecret
	// realm := config.C.Server.KeyCloakRealm
	form := url.Values{}
	form.Add("grant_type", "authorization_code")
	form.Add("code", authorizationCode)
	form.Add("client_id", config.C.Server.KeyCloakClientID)
	form.Add("client_secret", config.C.Server.KeyCloakSecret)
	form.Add("redirect_uri", config.C.Server.KeyRedirectURI)

	// Encode the form and create a new request body
	bodyReq := bytes.NewBufferString(form.Encode())

	// Create a new HTTP client and POST request
	response, err := http.Post(config.C.Server.KeyCloakBaseURL+"/realms/"+config.C.Server.KeyCloakRealm+util.KeyCloak.Token, "application/x-www-form-urlencoded", bodyReq)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	body, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	var jwt *gocloak.JWT

	// Decode the response body into a JWT object
	json.Unmarshal(body, &jwt)
	if err != nil {
		return nil, err
	}
	// client := gocloak.NewClient(hostname)
	// context := context.Background()
	// token, err := client.Login(context, clientid, clientSecret, realm, "demo", "demo")
	// if err != nil {
	// 	panic("Login failed:" + err.Error())
	// }

	return jwt, nil
}

func (ar *authRepository) GetIntroSpect(token string) (gocloak.IntroSpectTokenResult, error) {
	client := gocloak.NewClient(config.C.Server.KeyCloakBaseURL)
	ctx := context.Background()
	rptResult, err := client.RetrospectToken(ctx, token, config.C.Server.KeyCloakClientID, config.C.Server.KeyCloakSecret, config.C.Server.KeyCloakRealm)
	if err != nil {
		panic("Inspection failed:" + err.Error())
	}

	return *rptResult, nil
}

func (ar *authRepository) GetUserInfo(token string) (*gocloak.UserInfo, error) {
	client := &http.Client{}

	// Create a new GET request to the Keycloak userinfo endpoint
	req, err := http.NewRequest("GET", config.C.Server.KeyCloakBaseURL+"/realms/"+config.C.Server.KeyCloakRealm+util.KeyCloak.User, nil)
	if err != nil {
		return nil, err
	}

	// Set the Authorization header with the access token
	req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", token))

	// Send the request
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// Read the response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	// Decode the response body into a UserInfo object
	var userInfo *gocloak.UserInfo
	json.Unmarshal(body, &userInfo)
	if err != nil {
		return nil, err
	}

	return userInfo, nil
}

func (ar *authRepository) CreateLocalJWT(information map[string]interface{}) (string, error) {
	// Create a JWT token with the data.
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims(information))

	// Sign the token with a secret key.
	tokenString, err := token.SignedString([]byte("secret"))
	if err != nil {
		return "", err
	}
	return tokenString, nil
}
