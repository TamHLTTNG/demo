package repository

import (
	"go-auth-poc/pkg/domain/model"
	"go-auth-poc/pkg/util"

	"github.com/jinzhu/gorm"
)

type userRepository struct {
	db *gorm.DB
}

func NewUserRepository(db *gorm.DB) UserRepository {
	return &userRepository{db}
}

func (ur *userRepository) CreateUser(u *model.User) (*model.User, error) {
	if err := ur.db.Create(u).Error; err != nil {
		return nil, &util.QueryError{Message: err.Error()}
	}
	return u, nil
}

func (ur *userRepository) DeleteUser(u *model.User) error {
	if err := ur.db.Delete(u).Error; err != nil {
		return &util.QueryError{Message: err.Error()}
	}
	return nil
}

func (ur *userRepository) GetUser(u *model.User) (*model.User, error) {
	user := &model.User{}
	err := ur.db.Where(u).First(user).Error
	if err != nil {
		return nil, &util.QueryError{Message: err.Error()}
	}
	return user, nil
}
func (ur *userRepository) GetUserEmail(email string) (*model.User, error) {
	var user model.User
	if err := ur.db.Where("email = ?", email).First(&user).Error; err != nil {
		return nil, &util.QueryError{Message: err.Error()}
	}
	return &user, nil
}

func (ur *userRepository) GetUsers(u []*model.User) ([]*model.User, error) {
	err := ur.db.Find(&u).Error
	if err != nil {
		return nil, &util.QueryError{Message: err.Error()}
	}
	return u, nil
}

func (ur *userRepository) UpdateUser(u *model.User) (*model.User, error) {
	if err := ur.db.Save(u).Error; err != nil {
		return nil, &util.QueryError{Message: err.Error()}
	}
	return u, nil
}
