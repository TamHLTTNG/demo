package repository

import (
	"go-auth-poc/pkg/util"
	"log"

	"github.com/jinzhu/gorm"
)

type DBRepository interface {
	Transaction(func(interface{}) (interface{}, error)) (interface{}, error)
}

type dbRepository struct {
	db *gorm.DB
}

func NewDBRepository(db *gorm.DB) DBRepository {
	return &dbRepository{db}
}

func (r *dbRepository) Transaction(txFunc func(interface{}) (interface{}, error)) (data interface{}, err error) {
	tx := r.db.Begin()
	if tx.Error != nil {
		return nil, &util.InternalServerError{Message: tx.Error.Error()}
	}

	defer func() {
		if p := recover(); p != nil {
			log.Print("recover")
			tx.Rollback()
			panic(p)
		} else if err != nil {
			log.Print("rollback")
			tx.Rollback()
			panic("error")
		} else {
			err = tx.Commit().Error
		}
	}()

	data, err = txFunc(tx)
	return data, &util.InternalServerError{Message: err.Error()}
}
