package repository

import (
	"go-auth-poc/pkg/domain/model"

	"github.com/Nerzal/gocloak/v13"
)

type AuthRepository interface {
	GetAccessToken(authorizationCode string) (*gocloak.JWT, error)
	GetIntroSpect(token string) (gocloak.IntroSpectTokenResult, error)
	GetUserInfo(token string) (*gocloak.UserInfo, error)
	CreateLocalJWT(information map[string]interface{}) (string, error)
}

type UserRepository interface {
	CreateUser(u *model.User) (*model.User, error)
	DeleteUser(u *model.User) error
	GetUser(u *model.User) (*model.User, error)
	GetUserEmail(email string) (*model.User, error)
	GetUsers(u []*model.User) ([]*model.User, error)
	UpdateUser(u *model.User) (*model.User, error)
}
