package controller

type AppController struct {
	Auth interface{ Auth }
}
