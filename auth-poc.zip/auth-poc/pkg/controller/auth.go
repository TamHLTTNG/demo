package controller

import (
	"fmt"
	"go-auth-poc/pkg/config"
	"go-auth-poc/pkg/domain/model"
	"go-auth-poc/pkg/domain/model/auth"
	"go-auth-poc/pkg/repository"
	"go-auth-poc/pkg/usecase"
	"go-auth-poc/pkg/util"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func (r *registry) NewAuthController(db *gorm.DB) Auth {
	t := usecase.NewAuthUseCase(repository.NewAuthRepository(db))
	u := usecase.NewUserUsecase(repository.NewUserRepository(db))

	return NewAuthController(t, u)
}

type Auth interface {
	POSTVerifyToken(c *gin.Context)
	POSTGetUserInfo(c *gin.Context)
	POSTAuth(c *gin.Context)
	GETCallback(c *gin.Context)
	POSTValidToken(c *gin.Context)
}

type authController struct {
	authUseCase usecase.AuthUseCase
	userUseCase usecase.UserUseCase
}

func NewAuthController(ac usecase.AuthUseCase, uc usecase.UserUseCase) Auth {
	return &authController{ac, uc}
}

// POSTVerifyToken godoc
// @Summary アクセストーケン取得
// @Description アクセストークン取得する
// @Tags authentication
// @Accept  json
// @Produce  json
// @Param information body auth.AuthorizationCodeRequest true "Authorization Code"
// @Success 200 {string} string "Param is valid"
// @Failure 400 {string} string "missing Param"
// @Failure 401 {string} string "Param is invalid"
// @Failure 500 {string} string "Internal Server Error"
// @Router /get-jwt [post]
func (ac *authController) POSTVerifyToken(c *gin.Context) {

	var codeRequest auth.AuthorizationCodeRequest

	if err := c.BindJSON(&codeRequest); err != nil {
		util.HandleError(c, err)
		return
	}

	token, err := ac.authUseCase.GetAccessToken(codeRequest.Code)

	if err != nil {
		c.AbortWithStatusJSON(500, err)
	} else {
		c.JSON(http.StatusOK, map[string]string{
			"jwtToken": token,
		})
	}

}

// POSTGetUserInfo godoc
// @Summary ユーザー情報を取得
// @Description ユーザー情報を取得
// @Tags authentication
// @Accept  json
// @Produce  json
// @Param information body auth.TokenVerifyRequest true "Token"
// @Success 200 {string} string "Param is valid"
// @Failure 400 {string} string "missing Param"
// @Failure 401 {string} string "Param is invalid"
// @Failure 500 {string} string "Internal Server Error"
// @Router /get-userinfo [post]
func (ac *authController) POSTGetUserInfo(c *gin.Context) {

	var token auth.TokenVerifyRequest

	if err := c.BindJSON(&token); err != nil {
		util.HandleError(c, err)
		return
	}

	userinfo, err := ac.authUseCase.GetKeyCloakUserInfo(token.Token)

	if err != nil {
		c.AbortWithStatusJSON(500, err)
	} else {
		c.JSON(http.StatusOK, userinfo)
	}

}

// POSTAuth godoc
// @Summary ログイン処理する
// @Description ログイン処理する
// @Tags authentication
// @Success 200 {string} string "Param is valid"
// @Success 302 {string} string "Redirected"
// @Failure 400 {string} string "missing Param"
// @Failure 401 {string} string "Param is invalid"
// @Failure 500 {string} string "Internal Server Error"
// @Router /login-link [get]
func (ac *authController) POSTAuth(c *gin.Context) {
	hostName := config.C.Server.KeyCloakBaseURL
	realm := config.C.Server.KeyCloakRealm
	clientID := config.C.Server.KeyCloakClientID
	clientSecret := config.C.Server.KeyCloakSecret
	redirectURI := config.C.Server.KeyRedirectURI
	prefixAuth := "/realms/"
	uri1 := "/protocol/openid-connect/auth?client_id="
	uri2 := "&response_type=code&client_secret="
	uri3 := "&redirect_uri="
	uri := fmt.Sprintf("%s%s%s%s%s%s%s%s%s",
		hostName, prefixAuth, realm, uri1, clientID, uri2, clientSecret, uri3, redirectURI)
	c.Redirect(302, uri)
}

func (ac *authController) GETCallback(c *gin.Context) {

	params := c.Request.URL.Query()

	paramsMap := make(map[string]string)
	for key, values := range params {
		paramsMap[key] = values[0]
	}

	jwtToken, err := ac.authUseCase.GetAccessToken(paramsMap["code"])
	if err != nil {
		util.HandleError(c, err)
		return
	}

	user, err := ac.authUseCase.GetKeyCloakUserInfo(jwtToken)
	if err != nil {
		util.HandleError(c, err)
		return
	} else if user != nil {
		userDB, err := ac.userUseCase.Create(&model.User{
			Name:      *user.PreferredUsername,
			Email:     *user.Email,
			Password:  "",
			RoleID:    1,
			Token:     jwtToken,
			CreatedAt: time.Now(),
		})
		if err != nil {
			util.HandleError(c, err)
			return
		}
		// c.JSON(http.StatusOK, userDB)

		uri := fmt.Sprintf("http://localhost:9000/redirect?jwt=%s&user=%s", jwtToken, userDB.Email)
		c.Redirect(302, uri)
		return
	}
	c.JSON(403, &model.Response{
		Code: 403,
		Data: map[string]string{
			"message": "Failed Service",
		},
	})
}

// POSTValidToken godoc
// @Summary アクセストーケン取得
// @Description アクセストークン取得する
// @Tags authentication
// @Accept  json
// @Produce  json
// @Param information body auth.TokenVerifyRequest true "Access Token"
// @Success 200 {string} string "Param is valid"
// @Failure 400 {string} string "missing Param"
// @Failure 401 {string} string "Param is invalid"
// @Failure 500 {string} string "Internal Server Error"
// @Router /valid-token [post]
func (ac *authController) POSTValidToken(c *gin.Context) {

	var token auth.TokenVerifyRequest

	if err := c.BindJSON(&token); err != nil {
		util.HandleError(c, err)
		return
	}

	rs, err := ac.authUseCase.ValidateToken(token.Token)

	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	} else {
		if !rs {
			c.AbortWithStatusJSON(http.StatusForbidden, err)
			return
		}
		user, err := ac.authUseCase.GetKeyCloakUserInfo(token.Token)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusForbidden, err)
			return
		} else if user != nil {
			c.AbortWithStatusJSON(http.StatusForbidden, err)
			return
		}
		userDB, err := ac.userUseCase.Create(&model.User{
			Name:      *user.PreferredUsername,
			Email:     *user.Email,
			Password:  "",
			RoleID:    1,
			Token:     token.Token,
			CreatedAt: time.Now(),
		})
		if err != nil {
			util.HandleError(c, err)
			return
		}
		c.JSON(http.StatusOK, map[string]interface{}{
			"active": rs,
			"jwt":    token.Token,
			"user":   userDB,
		})
	}

}
